import java.util.Scanner;
import java.lang.*;
import java.io.*;



/**
 * @author Surendra Maddula <BR>
 * PSU ID: 939583141 <BR>
 * Project 1 - Quiz based Java Console Application.<BR><BR>
 * This is quiz class which consists of questions and score as variable and has methods such as <BR><BR> 
 * constructor of the class,getquestion,setscore,getscore,checkanswer  to work around with these variables. 
 * The class has a parameterized constructor. 
 */
 public class quiz{
	private String[][] questions;
	private int score;
	static final String optionA = "A";
	static final String optionB = "B";
	static final String optionC = "C";
	static final String optionD = "D";
	final int QUESTION = 0;	
	/**
	 * This is the parameterized constructor.<BR>
	 * Used to Initialize the questions from the questions_pool.
	 * @param q -- This is the 2D string array passed from the quiz_test while instantiating.
	 */
	quiz(String[][] q){
		questions = q;
	}	
	/**
	 * This is the mutator method used to get the question to the user.
	 */
	public void getquestion(){
		for(int i=0;i<questions.length-1;i++){
			System.out.println(questions[i]);	
			System.out.println();
		}		
	}
	/**
	 * This method is made private so that is not accessed from other classes.<BR>
	 * This method checks for the correct answer. The answer for the quesiton is in the last index of the question string itself.<BR>
	 * If the user enters the right answer for the question it returns true, otherwise it returns false.<BR>
	 * @param ans -- ans is a String variable used to store the user input for the choice.
	 * @param index -- index is an integer variable, used to get the question number.
	 * @return it returns either true or false based on the correctness of the answer.
	 */
	private boolean checkanswer(String ans, int index){
		if((ans.toUpperCase()).equals(questions[index][questions[index].length-1])){
			//System.out.println("Correct Answer!");	
			//score++;
			return true;
		}
		else{
			//System.out.println("Incorrect Answer!");
			return false;
		}
	}
	/**
	 * This method is made private so that is not accessed from other classes.<BR>
	 * The functionality of this method is to Increment the score when the user hit the right answer.<BR>
	 */
	private void setscore(){
		score++;
	}
	/**
	 *This below method give the score after the user completes all the questions. 
	 * @return
	 */
	public int getscore(){
		return score;
	}
	/**
	 *The startquiz is the main method, which  actually starts the quiz. by looping around the 2D array of questions. 
	 */
	public void startquiz(){
		for(int i=0;i<questions.length;i++)
		{
			System.out.println(questions[i][QUESTION]);
			System.out.println();
			for(int j=1;j<questions[i].length-1;j++)
			{
				System.out.println(questions[i][j]);
				System.out.println();
			}
			//User Input for the answer.
			Scanner keyboard = new Scanner(System.in);
			String answer = keyboard.nextLine();
			//The below conditions validates whether the input is valid or not. i.e it should be among A, B, C, D . Otherwise it will prompt user to enter the 
			//valid answer and checks again. It breaks when it is valid.
			while(!(((answer.toUpperCase()).equals(optionA)) || ((answer.toUpperCase()).equals(optionB)) || ((answer.toUpperCase()).equals(optionC)) || 
			((answer.toUpperCase()).equals(optionD)))){
				System.out.println( "Invalid Answer" +answer + ". Please select from below choices only");
				System.out.print(optionA + " ");
				System.out.print(optionB + " ");
				System.out.print(optionC + " ");
				System.out.println(optionD);
				answer = keyboard.nextLine();
			}
			//Checks for the answer, If it is correct the score gets incremented.
			if(checkanswer(answer,i)){
				System.out.println("Correct Answer!");
				setscore();
			}
			else{
				System.out.println("Incorrect Answer!");
			}
			System.out.println("=============================================================");
		}		
	}
}