import java.util.Scanner;
import java.lang.*;
import java.io.*;

/**
 * @author Surendra Maddula <BR>
 * PSU ID: 939583141 <BR>
 * Project 1 - Quiz based Java Console Application.<BR><BR>
 * This is quiz test class which has the main to start with. In this class we instantiate quiz object and start the quiz, by calling startquiz method.<BR><BR>
 *  
 */
public class quiz_test{
	
	public static void main(String[] args){
		final int PERCENT = 100;
		//The below is the questions which are going to be send to the quiz object that we had instantiated above.
		String[][] question_pool = {
												{"Who is the first president of America?","A.George Washington ?","B.John F.Kenedy","C.Bill Clinton","D.Abraham Lincoln","A"},
												{"Most Innovative company in 2016 ?", "A.Netflix","B.ARM","C.Tesla Motors","D.Amazon","C"},
												{"In Rio Olympics 2016, Which country won highest number of medals ?", "A.China","B.America","C.Russia","D.Japan","B"},
												{"Which State of USA was once part of Mexico ?", "A.Texas","B.Maryland","C.New York","D.Alaska","A"},
												{"What is the number of states in USA ?", "A.24","B.50","C.60","D.49","B"},
												{"Which city is known as the Big Apple ?", "A.Los Angles","B.HOuston","C.New York","D.Washington D.C","C"},
												{"Who had the longest tenure as President of USA ?", "A.George Washington","B.Franklin D. Roosevelt","C.John F. Kennedy","D.James Carter","B"},
												{"How many stars are in the flag of USA ? ", "A.34","B.56","C.50","D.75","C"}
												};
		//Instantiating object of quiz class.
		quiz q1 = new quiz(question_pool);
		//This is another public method in quiz class which is used to start the quiz.
		q1.startquiz();
		System.out.println("You have scored " +q1.getscore() + " out of " + question_pool.length);
		System.out.println("Your score is " + (q1.getscore() * PERCENT)/question_pool.length + "%");
		}		
	}
