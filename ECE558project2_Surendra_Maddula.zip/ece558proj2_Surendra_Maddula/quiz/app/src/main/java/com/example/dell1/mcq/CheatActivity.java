package com.example.dell1.mcq;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * @author  Surendra Maddula
 * PSU ID: 939583141
 * This is the Cheat Activity, which is launched when the user presses the cheat button.
 * The user can go back to main activity by pressing the back button.
 */
public class CheatActivity extends Activity {
    private static final String TAG = "MCQActivity";
    private static final String KEY_INDEX = "index";
    private boolean mCheated = false;

    public static final String EXTRA_ANSWER_IS_TRUE = "com.example.dell1.mcq.answer_is_true";
    public static final String EXTRA_ANSWER_SHOWN = "com.example.dell1.mcq.answer_shown";
    private boolean mAnswerIsTrue;
    private TextView mAnswer;

    private Button mShowAnswer;


    /**
     *The main purpose of this method is to put the user cheated value to an intent and send it to the MainActivity.
     *
     * @param isAnswerShown - The is the boolean value which tell whether the user has cheated or not.
     *                      It has been passed form the onclick listener of the showanswer button.
     */
    private void setAnswerShownResult(boolean isAnswerShown){
        Intent data = new Intent();
        Log.d(TAG,"CHEATED = "+isAnswerShown);
        data.putExtra(EXTRA_ANSWER_SHOWN,isAnswerShown);
        setResult(RESULT_OK,data);//pass the result to the MainActivity.
    }

    /**
     *The method onSaveInstanceState is overriden to save some parameters for the further user when screen is rotated.
     * @param savedInstanceState -- This is the bundle in which we store the information regarding the user cheating
     *                           which are used upon screen rotation.
     */
    @Override
    protected void onSaveInstanceState(android.os.Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        Log.i(TAG,"onSaveInstanceState cheatactivity");
        savedInstanceState.putBoolean(KEY_INDEX,mCheated);
    }

    /**
     *This method is the is first created when you start an activity.
     * This is where you should do all of your normal static set up: create views, bind data to lists, etc.
     * This method also provides you with a Bundle containing the activity's previously frozen state, if there was one.
     *Always followed by onStart().
     * @param savedInstanceState --This is the Bundle where we have store all the state information. when we do screen rotation.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cheat);
        setAnswerShownResult(false);
        Bundle p = getIntent().getExtras();
        final String answer = p.getString("answer");
        mAnswer = (TextView)findViewById(R.id.answerTextView);
        mShowAnswer = (Button)findViewById(R.id.show_answer_button);
        mShowAnswer.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                mAnswer.setText(answer);
                android.util.Log.d(TAG,"answer" +answer);
                mCheated = true;
                setAnswerShownResult(true);
            }
        });

        if (savedInstanceState != null) {
            mCheated = savedInstanceState.getBoolean(KEY_INDEX, false);
            Log.d(TAG,"mCheated = " +mCheated);
            if(mCheated){
                Log.d(TAG,"inside cheated true");
                setAnswerShownResult(true);
                mAnswer.setText(answer);
            }
        }
    }
}
