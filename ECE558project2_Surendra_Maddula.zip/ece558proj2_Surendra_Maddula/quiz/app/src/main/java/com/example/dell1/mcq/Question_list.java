package com.example.dell1.mcq;

/**
 * @author  Surendra Maddula
 * PSU ID: 939583141
 * This is single question class,where it can have a question and 4 options encapsulated.
 */

public class Question_list {
    private String mQuestion;
    private String mAnswer;
    private String moption1;
    private String moption2;
    private String moption3;
    private String moption4;

    /*public void set_ques_and_answer(String question, String answer) {
        mQuestion = question;
        mAnswer = answer;
    }*/

    Question_list(String question, String op1, String op2, String op3, String op4, String answer){
        mQuestion = question;
        moption1 = op1;
        moption2 = op2;
        moption3 = op3;
        moption4 = op4;
        mAnswer = answer;
    }

    /**
     * This method returns the question.
     * @return - it returns the question.
     */
    public String getQuestion() {
        return mQuestion;
    }

    /**
     * This method returns the option 1.
     * @return it returns the option1
     */
    public String getMoption1(){
        return moption1;
    }

    /**
     * This method returns the option 2.
     * @return it returns option 2
     */
    public String getMoption2(){
        return moption2;
    }

    /**
     * This method returns the option 3.
     * @return it returns option 3
     */
    public String getMoption3(){
        return moption3;
    }

    /**
     * This method returns the option 4.
     * @return it returns option 4
     */
    public String getMoption4(){
        return moption4;
    }

    /**
     * This method returns the answer to the quesiton.
     * @return -it returns the answer to the quesiton.
     */
    public String getAnswer() {
        return mAnswer;
    }
}
