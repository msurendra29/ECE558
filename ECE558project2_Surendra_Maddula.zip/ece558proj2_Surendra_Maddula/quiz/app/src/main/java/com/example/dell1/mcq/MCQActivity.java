package com.example.dell1.mcq;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

/**
 * @author  Surendra Maddula
 * PSU ID: 939583141
 * This is the Main Activity the app launches after installing.
 */
public class MCQActivity extends AppCompatActivity {

    private static final String TAG = "MCQActivity";
    private static final int NO_OF_QUESTIONS = 7;
    private static final String KEY_INDEX = "index";
    private static final String KEY_SCORE = "score";
    private static final String KEY_FINISHED = "finished";
    private static final String KEY_CHEATER = "Cheated";
    private boolean mFinished = false;
    private Button mTrueButton;
    private Button mFalseButton;
    private Button mCheatButton;
    private RadioButton mOption1;
    private RadioButton mOption2;
    private RadioButton mOption3;
    private RadioButton mOption4;
    private int mScore = 0;
    private Button mNextButton;
    private Button mRetakeButton;
    private TextView mQuestionTextView;
    private TextView mResult;
    private RadioGroup mrg;
    private boolean mIsCheater;
    private boolean mTemp =false;
    private int[] mUserSelection = new int[NO_OF_QUESTIONS];
    //This is the 2d array of questions, where each row contains , question, four options and answer to the question.
    private String[][] question_pool = {
            {"How many stars are in the flag of USA ? ", "34", "56", "50", "75", "50"},
            {"Who is the first president of America?", "George Washington", "John F.Kenedy", "Bill Clinton", "Abraham Lincoln", "George Washington"},
            {"Which city is known as the Big Apple ?", "Los Angles", "HOuston", "New York", "Washington D.C", "New York"},
            {"Most Innovative company in 2016 ?", "Netflix", "ARM", "Tesla Motors", "Amazon", "Tesla Motors"},
            {"In Rio Olympics 2016, Which country won highest number of medals ?", "China", "America", "Russia", "Japan", "America"},
            {"Which State of USA was once part of Mexico ?", "Texas", "Maryland", "New York", "Alaska", "Texas"},
            {"What is the number of states in USA ?", "24", "50", "60", "49", "50"},
            {"Who had the longest tenure as President of USA ?", "George Washington", "Franklin D. Roosevelt", "John F. Kennedy", "James Carter", "Franklin D. Roosevelt"}

    };
    //Below is an array to store the questions from the question pool.
    private Question_list[] mQuestionBank = new Question_list[]{
            new Question_list(question_pool[0][0], question_pool[0][1], question_pool[0][2], question_pool[0][3], question_pool[0][4], question_pool[0][5]),
            new Question_list(question_pool[1][0], question_pool[1][1], question_pool[1][2], question_pool[1][3], question_pool[1][4], question_pool[1][5]),
            new Question_list(question_pool[2][0], question_pool[2][1], question_pool[2][2], question_pool[2][3], question_pool[2][4], question_pool[2][5]),
            new Question_list(question_pool[3][0], question_pool[3][1], question_pool[3][2], question_pool[3][3], question_pool[3][4], question_pool[3][5]),
            new Question_list(question_pool[4][0], question_pool[4][1], question_pool[4][2], question_pool[4][3], question_pool[4][4], question_pool[4][5])
    };

    //mCurrentIndex is the index of the current question. starting from zero.
    private int mCurrentIndex = 0;

    /**
     * This method updateQuestion(), updates the question and four options for the user to present the next question.
     * It doesn't take any arguments and do not return anything
     */
    private void updateQuestion() {
        String que = mQuestionBank[mCurrentIndex].getQuestion();
        mQuestionTextView.setText(que);
        Log.d(TAG,"mCurrentIndex" + mCurrentIndex +  mUserSelection[mCurrentIndex]);
        Log.d(TAG,"moption1 = " + mOption1.isChecked());
        Log.d(TAG,"moption2 = " + mOption2.isChecked());
        Log.d(TAG,"moption3 = " + mOption3.isChecked());
        Log.d(TAG,"moption4 = " + mOption4.isChecked());
        String opt1 = mQuestionBank[mCurrentIndex].getMoption1();
        mOption1.setText(opt1);                                  //Set option 1
        String opt2 = mQuestionBank[mCurrentIndex].getMoption2();
        mOption2.setText(opt2);                                 //Set option 2
        String opt3 = mQuestionBank[mCurrentIndex].getMoption3();
        mOption3.setText(opt3);                                 //Set option 3
        String opt4 = mQuestionBank[mCurrentIndex].getMoption4();
        mOption4.setText(opt4);                                 //Set option 4
        if(mFinished){ // The mFinished is a flag used to check the end of quiz .As the quiz ends the user should get only score and retake options.
           // mNextButton.setVisibility(View.GONE);
            mCheatButton.setVisibility(View.GONE);
            mQuestionTextView.setText("");
            mResult.setText("Your have scored " + mScore + " out of 5 questions");
            mRetakeButton.setVisibility(View.VISIBLE);
            mFinished = false;//Resetting.

        }
    }

    /**
     * This method checkAnswer does the verification of the answer chosen by the user .
     * It Toasts whether user has cheated or not. If the user has not cheated it toasts the correctness of the answer.
     * @param userPressedChoice -- This is the user choice out of 4 options given
     */
    private void checkAnswer(String userPressedChoice) {
        String answer = mQuestionBank[mCurrentIndex].getAnswer();
        int messageResId = 0;
        Log.d(TAG,"mIsCheater = " +mIsCheater);
        if(mTemp){
            messageResId = R.string.judgment_toast;//User has cheated.
        } else {
            if (userPressedChoice.equals(answer)) {
                messageResId = R.string.correct_toast;//Correct Answer
                mScore++;
            } else {
                messageResId = R.string.incorrect_toast; //Incorret Answer
            }

        }
        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show();
        mIsCheater = false;//Reset to default, to avoid next quesiton marked as cheated without actual cheating.
    }

    /**
     *The method onSaveInstanceState is overriden to save some parameters for the further user when screen is rotated.
     * @param savedInstanceState -- This is the bundle in which we store the information regarding the index, score, and other values
     *                           which are used upon screen rotation.
     */
    @Override
    protected void onSaveInstanceState(android.os.Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        Log.i(TAG,"onSaveInstanceState");
        savedInstanceState.putInt(KEY_INDEX, mCurrentIndex);
        savedInstanceState.putInt(KEY_SCORE, mScore);
        savedInstanceState.putBoolean(KEY_FINISHED,mFinished);
        savedInstanceState.putBoolean(KEY_CHEATER,mTemp);
    }

    /**
     * This is the callback method called when the other activity we start exits and returns to the main activity.
     * @param requestCode -- This is what the MCQ activity passes to cheat activity . to identify to which activity it has passed.
     * @param resultCode -- This the result back from the cheat activity.
     * @param data -- This is where we get store, whether the user has cheated or not value. It store the resultl data.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(data == null){
            return;
        }
        mIsCheater = data.getBooleanExtra(CheatActivity.EXTRA_ANSWER_SHOWN,false);
        mTemp = mIsCheater;//This is store the value we get from cheatActivity and reuse when we rotate screen.
        Log.d(TAG,"mIscheater in onActivityResult = " + mIsCheater);
    }

    /**
     *This method is the is first created when you start an activity.
     * This is where you should do all of your normal static set up: create views, bind data to lists, etc.
     * This method also provides you with a Bundle containing the activity's previously frozen state, if there was one.
     *Always followed by onStart().
     * @param savedInstanceState --This is the Bundle where we have store all the state information. when we do screen rotation.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG,"onCreate bundle called");
        setContentView(R.layout.activity_mcq);
        if (savedInstanceState != null) {
            mCurrentIndex = savedInstanceState.getInt(KEY_INDEX, 0);
            mScore = savedInstanceState.getInt(KEY_SCORE,0);
            mFinished = savedInstanceState.getBoolean(KEY_FINISHED,false);
            mTemp = savedInstanceState.getBoolean(KEY_CHEATER,false);
            Log.d(TAG,"rotated and index = " +mCurrentIndex + "score = " +mScore + "and finished = "+mFinished + "cheated = "+mTemp);
        }
        for(int i =0; i<mUserSelection.length;i++){
            mUserSelection[i] = 0;//This is used for implementeation of prev button.
        }
        mQuestionTextView = (TextView) findViewById(R.id.question_text_view);
        mrg = (RadioGroup)findViewById(R.id.radio_group);
        mResult = (TextView)findViewById(R.id.result);
        //mNextButton = (Button) findViewById(R.id.next_button);
        mRetakeButton = (Button)findViewById(R.id.retake);
        if(mRetakeButton != null){
            mRetakeButton.setVisibility(View.GONE);
        }
        mOption1 = (RadioButton) findViewById(R.id.option1);
        mOption2 = (RadioButton) findViewById(R.id.option2);
        mOption3 = (RadioButton) findViewById(R.id.option3);
        mOption4 = (RadioButton) findViewById(R.id.option4);
        mCheatButton = (Button) findViewById(R.id.cheat_button);
        if(!mFinished){
           // mNextButton.setVisibility(View.VISIBLE);
            mCheatButton.setVisibility(View.VISIBLE);
            mResult.setText("");
            mRetakeButton.setVisibility(View.GONE);


        }
        updateQuestion();//Goes to next question.
        //if(mCheatButton != null){
            mCheatButton.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(android.view.View v) {
                    Intent i = new Intent(MCQActivity.this,CheatActivity.class);
                    String ans = mQuestionBank[mCurrentIndex].getAnswer();
                    Log.d(TAG,"answer from main is " +ans);
                    i.putExtra("answer",ans);
                    startActivityForResult(i,0);//Go to cheat Activity.
                }
            });

        //}
        mQuestionTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                int id = mrg.getCheckedRadioButtonId();
                if(id!=-1){//If the user has not selected any choice, then simple go to next question upon next.
                    View radButton = mrg.findViewById(id);
                    int radId = mrg.indexOfChild(radButton);
                    RadioButton btn = (RadioButton)mrg.getChildAt(radId);
                    String selection = (String)btn.getText();
                    Log.d(TAG,"mIsCheater before calling checkanswer = " +mIsCheater);
                    checkAnswer(selection);//Verify the answer.
                    mTemp = false;
                }
                mCurrentIndex = (mCurrentIndex + 1);
                Log.d(TAG,"mCurrentIndex in Next " + mCurrentIndex);
                if(mCurrentIndex<mQuestionBank.length){
                    mrg.clearCheck();//Clear options as we move to the next quesiton.
                    updateQuestion();//update the question.
                }
                else{
                    mCurrentIndex = mQuestionBank.length-1;
                    //mNextButton.setVisibility(View.GONE);
                    mCheatButton.setVisibility(View.GONE);
                    mQuestionTextView.setClickable(false);
                    mResult.setText("Your have scored " + mScore + " out of 5 questions");
                    mRetakeButton.setVisibility(View.VISIBLE);
                    mFinished = true;
                }
            }
        });

       /* mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id = mrg.getCheckedRadioButtonId();
                if(id!=-1){//If the user has not selected any choice, then simple go to next question upon next.
                    View radButton = mrg.findViewById(id);
                    int radId = mrg.indexOfChild(radButton);
                    RadioButton btn = (RadioButton)mrg.getChildAt(radId);
                    String selection = (String)btn.getText();
                    Log.d(TAG,"mIsCheater before calling checkanswer = " +mIsCheater);
                    checkAnswer(selection);
                    mTemp = false;

                }
                mCurrentIndex = (mCurrentIndex + 1);
                Log.d(TAG,"mCurrentIndex in Next " + mCurrentIndex);
                if(mCurrentIndex<mQuestionBank.length){
                    mrg.clearCheck();
                    updateQuestion();
                }
                else{
                    mCurrentIndex = mQuestionBank.length-1;
                    mNextButton.setVisibility(View.GONE);
                    mCheatButton.setVisibility(View.GONE);
                    mResult.setText("Your have scored " + mScore + " out of 5 questions");
                    mRetakeButton.setVisibility(View.VISIBLE);
                    mFinished = true;

                }
            }
        });*/

        /**
         * This is the Listener called when the user presses the retake button once finished with the quiz.
         * Where it starts the quiz again.
         *
         */
        mRetakeButton.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                mCurrentIndex = 0; //Starting the quiz again .
                mScore=0;//Initializing score to zero, as user is taking the test again.
                mResult.setText("");
              //  mNextButton.setVisibility(View.VISIBLE);
                mQuestionTextView.setClickable(true);
                mCheatButton.setVisibility(View.VISIBLE);
                mrg.clearCheck();//Resetting the radiobuttons.
                mRetakeButton.setVisibility(View.GONE);//Here we go to starting of the quiz, where retake button should not be present. so make it gone.
                mFinished = false;
                updateQuestion();//Go to the next question.
            }
        });
        /**
         *
         */
        /**
         * This is the listener called when the user selects any one option in the radiogroup.
         * In our case, the user is presented with the 4 options and he selects any one option. then this is called.
         *
         */
        mrg.setOnCheckedChangeListener(new android.widget.RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.RadioGroup group, int checkedId) {
                Log.d(TAG,"user selection " + checkedId);
                switch (checkedId){
                    case R.id.option1:
                        mUserSelection[mCurrentIndex]=1;
                        Log.d(TAG,"option  1");
                        break;
                    case R.id.option2:
                        mUserSelection[mCurrentIndex]=2;
                        Log.d(TAG,"option  2");
                        break;
                    case R.id.option3:
                        mUserSelection[mCurrentIndex]=3;
                        Log.d(TAG,"option  3");
                        break;
                    case R.id.option4:
                        mUserSelection[mCurrentIndex]=4;
                        Log.d(TAG,"option 4 ");
                        break;
                    default:
                        break;
                }
            }
        });
        mIsCheater = false;
        updateQuestion();
    }
    /**
     * Called when the activity is becoming visible to the user.
     * Followed by onResume() if the activity comes to the foreground, or onStop() if it becomes hidden.
     */
    @Override
    public void onStart() {
        super.onStart();
       Log.d(TAG,"onStart called");
    }

    /**
     * Called when the system is about to start resuming a previous activity.
     * This is typically used to commit unsaved changes to persistent data, stop animations and other things that may be
     * consuming CPU, etc. Implementations of this method must be very quick because the next activity will not be resumed
     * until this method returns.Followed by either onResume() if the activity returns back to the front, or onStop() if
     * it becomes invisible to the user.
     */
    @Override
    public void onPause(){
        super.onPause();
        Log.d(TAG,"onPause called");
    }

    /**
     * Called when the activity will start interacting with the user. At this point your activity is at the top
     * of the activity stack, with user input going to it.
     Always followed by onPause().
     */
    @Override
    public void onResume(){
        super.onResume();
        Log.d(TAG,"onResume called");
    }

    /**
     * Called when the activity is no longer visible to the user,
     * because another activity has been resumed and is covering this one.
     * This may happen either because a new activity is being started, an existing one is being brought
     * in front of this one, or this one is being destroyed. Followed by either onRestart() if this activity
     * is coming back to interact with the user, or onDestroy() if this activity is going away.
     */
    @Override
    public void onStop() {
        super.onStop();
       Log.d(TAG,"onStop called");
    }
    /**
     * The final call you receive before your activity is destroyed.
     * This can happen either because the activity is finishing (someone called finish() on it,
     * or because the system is temporarily destroying this instance of the activity to save space.
     * You can distinguish between these two scenarios with the isFinishing() method.
     */
    @Override
    public void onDestroy(){
        super.onDestroy();
        Log.d(TAG,"onDestroy called");
    }
}
